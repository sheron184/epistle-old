﻿//English texts are included in rte-config.js

//Include this file or not , does not matter
